// MathJax config JS - placeholder
console.log('MathJax config placeholder loaded');
